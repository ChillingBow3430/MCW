$('.slider-main').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    prevArrow: '.arrow-prev',
    nextArrow: '.arrow-next',
});